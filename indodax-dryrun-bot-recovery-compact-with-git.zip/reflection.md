# Refleksi forward test

Lengkapi setelah forward test berakhir, menggunakan `data/backtest_summary.json`, log mentah dari `logs/raw/`, dan `dashboard/offline_dashboard.html`. Jangan mengisi angka sebelum dihasilkan oleh skrip.

## Kecocokan sinyal

- Jumlah candle terjadwal:
- Jumlah candle yang diproses tepat waktu / uptime:
- Sinyal yang cocok per candle pada pembanding backtest 10 hari:
- Sinyal yang berbeda dan bukti log penyebabnya:

## Hasil dan benchmark

- Return dan maximum drawdown backtest 3 tahun:
- Return dan maximum drawdown backtest pada 10 hari yang sama:
- Return dan maximum drawdown forward:
- Return buy-and-hold BTC/IDR:
- Gap return backtest 10 hari vs forward:

## Eksekusi dan operasional

- Fee aktual yang digunakan dan sumber resmi/tanggal akses:
- Median spread dari snapshot persiapan dibanding seluruh snapshot:
- Market impact/slippage median dan rentang:
- Rata-rata keterlambatan jadwal dan candle terlewat:
- Error API, kill-switch, serta dampak pada entry/exit:
- Faktor terukur lain yang menjelaskan selisih backtest dan forward:

Cantumkan hanya nilai yang dapat dihitung ulang dari source code dan raw log terlampir. Jelaskan selisih berdasarkan data; jangan menyimpulkan bahwa strategi berhasil hanya dari return.
