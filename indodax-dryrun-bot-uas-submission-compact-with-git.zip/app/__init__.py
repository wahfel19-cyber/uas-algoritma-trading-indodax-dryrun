"""Trading app package."""
