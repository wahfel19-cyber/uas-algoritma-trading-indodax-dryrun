"""Vercel serverless API functions."""
